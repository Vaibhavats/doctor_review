# middleware/auth_dependency.py
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from bson import ObjectId
from config.database import get_users_collection
from middleware.jwt_handler import decode_token

bearer_scheme = HTTPBearer(auto_error=False)

async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> dict:
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authorised – no token provided",
                            headers={"WWW-Authenticate": "Bearer"})
    try:
        user_id = decode_token(credentials.credentials)
    except JWTError as e:
        msg = "Session expired – please login again" if "expired" in str(e).lower() else "Invalid token"
        raise HTTPException(status_code=401, detail=msg, headers={"WWW-Authenticate": "Bearer"})

    user = await get_users_collection().find_one({"_id": ObjectId(user_id)})
    if not user or not user.get("is_active", True):
        raise HTTPException(status_code=401, detail="Account not found or deactivated")
    return user

def require_role(*roles: str):
    async def _guard(current_user: dict = Depends(get_current_user)):
        if current_user.get("role") not in roles:
            raise HTTPException(status_code=403,
                detail=f"Role '{current_user.get('role')}' not authorised")
        return current_user
    return _guard
