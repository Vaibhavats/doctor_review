# middleware/jwt_handler.py
from datetime import datetime, timedelta, timezone
from jose import JWTError, jwt
from config.settings import get_settings

settings = get_settings()

def create_access_token(user_id: str) -> str:
    expire  = datetime.now(timezone.utc) + timedelta(minutes=settings.access_token_expire_minutes)
    payload = {"sub": user_id, "exp": expire, "iat": datetime.now(timezone.utc)}
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)

def decode_token(token: str) -> str:
    payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    user_id = payload.get("sub")
    if not user_id:
        raise JWTError("Missing sub")
    return user_id
